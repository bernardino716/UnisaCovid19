-Link dataset:
https://drive.google.com/drive/folders/1N6LHSUDkkpNOBHB2ZccLAbMmXM8yCViq?usp=sharing

-Link presentazione:
https://drive.google.com/drive/folders/18CFKWmsKZjccbTPRiHnq9X67krgfpfH2?usp=sharing